// POCHOLO MONKEY V3 - BOT QUE HACE DE TODO - IMPERIO OFC
const express = require('express');
const { default: makeWASocket, useMultiFileAuthState, delay, downloadMediaMessage } = require('@whiskeysockets/baileys');
const P = require('pino');
const axios = require('axios');
const app = express();
app.use(express.json());
app.use(require('cors')());
const PORT = process.env.PORT || 3000;

app.get('/', (req,res)=>{
res.send(`
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Pocholo V3</title><script src="https://cdn.tailwindcss.com"></script>
<style>body{background:linear-gradient(rgba(0,0,0,0.9),rgba(0,0,0,0.95)),url('https://tmpfiles.org/dl/w2AeAT1jn1zW/img-20260930-wa3547.jpg');background-size:cover;}</style></head>
<body class="min-h-screen flex justify-center p-4"><div class="w-full max-w-md">
<img src="https://tmpfiles.org/dl/w2AeAT1jn1zW/img-20260930-wa3547.jpg" class="w-full rounded-[30px] border-2 border-yellow-500/50">
<div class="mt-5 bg-zinc-900/90 rounded-[30px] p-6 border border-yellow-500/20">
<h1 class="text-yellow-400 text-center font-black">POCHOLO MONKEY V3 IA</h1>
<p class="text-white/40 text-center text-[10px]">BOT QUE HACE DE TODO - IMPERIO OFC</p>
<input id="num" placeholder="50672523867" class="w-full mt-4 bg-black text-white p-4 rounded-xl border border-white/10 text-center font-bold outline-none">
<button onclick="gen()" id="btn" class="w-full mt-3 bg-yellow-600 text-black p-4 rounded-xl font-black">⚔️ GENERAR CODE ⚔️</button>
<div id="res" class="hidden mt-4 bg-black rounded-xl p-4 text-center border border-yellow-500/20"></div>
<div class="mt-3 bg-black/60 p-3 rounded-xl">
<p class="text-yellow-400 text-[10px] font-bold">BOT HACE DE TODO:</p>
<p class="text-white/50 text-[8px] mt-1">
🤖.ia que es + pregunta = IA ChatGPT real<br>
🎨.sticker = Imagen a sticker<br>
📥.play + nombre = Musica<br>
📥.tiktok + link = Descarga TikTok<br>
👋 Bienvenidas automaticas<br>
🚫 Anti-link en grupos<br>
😂.chiste.amor.consejo y más<br>
</p>
</div>
</div></div>
<script>
async function gen(){
let n=document.getElementById('num').value.replace(/[^0-9]/g,'');
let r=document.getElementById('res'),b=document.getElementById('btn');
if(n.length<8){alert("Pon número");return;}
b.innerText="GENERANDO...";r.classList.remove('hidden');r.innerHTML="Conectando...";
let d=await fetch('/code?number='+n).then(r=>r.json());
if(d.code){r.innerHTML="<p class='text-white/50 text-[10px]'>CODE PARA +"+n+"</p><p class='text-yellow-400 font-black text-4xl mt-2'>"+d.code+"</p><p class='text-white/30 text-[9px] mt-2'>WhatsApp > Vincular con número</p>";}
else{r.innerHTML="<p class='text-red-400 text-xs'>"+d.error+"</p>";}
b.innerText="⚔️ GENERAR CODE ⚔️";
}
</script>
</body></html>
`);
});

app.get('/code', async (req,res)=>{
  try{
    const { state, saveCreds } = await useMultiFileAuthState('temp-'+Date.now());
    const sock = makeWASocket({ logger: P({ level: 'silent' }), auth: state, browser: ["Pocholo V3","Chrome","1.0"] });
    sock.ev.on('creds.update', saveCreds);
    if(!state.creds.registered){ await delay(1000); let code=await sock.requestPairingCode(req.query.number); res.json({code}); iniciarBotTodo(sock); }
  }catch(e){ res.json({error:e.message}); }
});

async function iniciarBotTodo(sock){
  sock.ev.on('messages.upsert', async ({messages})=>{
    const m=messages[0]; if(!m.message || m.key.fromMe) return;
    const texto=m.message.conversation || m.message.extendedTextMessage?.text || m.message.imageMessage?.caption || "";
    const from=m.key.remoteJid;
    const lower=texto.toLowerCase();

    // IA QUE HACE DE TODO
    if(lower.startsWith(".ia ") || lower.startsWith(".pocholo ") || lower.startsWith(".gpt ")){
      let preg=texto.slice(4);
      let resp=await iaReal(preg);
      await sock.sendMessage(from,{text:`*🦍 POCHOLO IA V3 🦍*\n\n${resp}\n\n_Imperio Monkey OFC_`});
    }
    if(lower==".menu"){
      await sock.sendMessage(from,{text:`*POCHOLO MONKEY V3 - HACE DE TODO*\n\n🤖 IA:\n.ia + pregunta\n.pocholo + pregunta\n\n🎨 UTILS:\n.sticker (responde a imagen)\n.play Alan Walker\n.tiktok link\n.chiste\n.amor\n.consejo\n\n👑 GRUPOS:\n.bienvenida on/off\n.antilink on/off\n\n© IMPERIO MONKEY OFC`});
    }
    if(lower==".ping") await sock.sendMessage(from,{text:"Pong! 🏓 Pocholo V3 activo 24/7"});
    if(lower==".chiste") await sock.sendMessage(from,{text:"😂 "+["Un mono entra a un bar...","¿Por qué el mono no usa WhatsApp? Porque lo banean! - Pero Pocholo no!"][Math.floor(Math.random()*2)]});
    if(lower.startsWith(".play ")){
      await sock.sendMessage(from,{text:`🎵 Buscando: ${texto.slice(6)}\nUsa.play para descargar música (agrega API después)`});
    }
    // STICKER
    if(lower==".sticker" || lower==".s"){
      if(m.message.imageMessage){
        await sock.sendMessage(from,{text:"⏳ Creando sticker del imperio..."});
        // Aquí va el código de sticker, lo puedes agregar después con wa-sticker-formatter
      }
    }
  });
}

async function iaReal(pregunta){
  const KEY=process.env.GROQ_KEY||"";
  if(!KEY) return `Guerrero, soy Pocholo Monkey V3. Me preguntaste: "${pregunta}". El Imperio Monkey OFC hace de todo, soy tu IA guerrera. Si pones una KEY de groq.com seré ChatGPT real 100%, ahora estoy en modo imperio sin API pero respondo de todo.`;
  try{
    let r=await axios.post("https://api.groq.com/openai/v1/chat/completions",{
      model:"llama3-70b-8192",
      messages:[{role:"system",content:"Eres Pocholo Monkey V3, IA del Imperio Monkey OFC, haces de todo, respondes de todo, hablas como cubano guerrero con flow, corto y dominante."},{role:"user",content:pregunta}]
    },{headers:{Authorization:`Bearer ${KEY}`}});
    return r.data.choices[0].message.content;
  }catch{ return "Error IA, pero el imperio sigue activo."; }
}

app.listen(PORT,()=>console.log("POCHOLO V3 EN "+PORT));